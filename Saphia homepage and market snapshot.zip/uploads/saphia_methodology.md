# ΣΟΦΙΑ — Methodology

Version 2.0 · September 2026 · supersedes the Snapshot draft v1.1

---

## 1. What this document is for

ΣΟΦΙΑ analyses markets that have almost nothing in common. Gold has an exchange, a daily fix and a century of audited statistics. Oud has none of those things — no benchmark, no production figure, no grading authority. A method that works only where the data is good is not a method; it is a habit that happens to suit gold.

This document sets out how ΣΟΦΙΑ analyses both, and everything between them, in a way a reader can check. It defines the analytical sequence, the rules that govern what may appear on a page, the four rating scales behind the Market Snapshot, and how work is refreshed and corrected. It is published because a reader who cannot audit the method has no reason to trust the conclusions.

**ΣΟΦΙΑ publishes market intelligence and data. It does not publish investment advice.** Nothing produced under this methodology is a recommendation to buy, sell or hold anything.

---

## 2. The analytical sequence

Every sector is examined through the same seven questions, in the same order.

| | Question | What it establishes |
|---|---|---|
| 1 | **Supply** | What exists, who has it, and what it costs to bring out |
| 2 | **Demand** | Who buys it, for what, and what they would substitute |
| 3 | **Concentration** | Where along the chain the power to set price actually sits |
| 4 | **Liquidity** | Whether a standard unit can be sold, to whom, at a knowable price |
| 5 | **Scarcity** | Whether supply can respond to price, and over what horizon |
| 6 | **Provenance** | Whether the thing is what the label says, and who verifies it |
| 7 | **Price formation** | How those six combine into the price a buyer pays |

The sequence is the product. A reader who understands the rare-earth separation bottleneck can read the Port benefício, the Habanos monopoly and the De Beers sight as versions of one mechanism — a controlled stage that concentrates pricing power away from the producer. Those parallels are drawn explicitly on the pages, and they are always tagged as inference rather than fact (§4).

### Two formats, one sequence

Markets differ in what can be known about them, so pages take one of two shapes.

**Data-driven** — used where a statistical body publishes a series: supply, demand and trade, price structure, regulation or ownership, indicators, sources. Gold, copper, cocoa, coffee, PGMs, silver, rare earths, olive oil, caviar, watches, art.

**Overview** — used where the market is defined by institutions, history and custom rather than by statistics: origins, one section per region or segment, a dated evolution timeline, structure of the trade today, indicators, sources. Fine wine, Port, Scotch whisky, truffles, frankincense, falcons, Arabian horses.

The format changes the layout. It does not change the sequence, the evidence rules, or the standard of proof.

---

## 3. What may appear on a page

### Cited or absent

Every quantitative claim carries a numbered citation resolving to the source list. Every source in the list is cited at least once in the body. No orphans, no dangling references. Where a figure is important and cannot be sourced, the page says so and leaves it out — an acknowledged gap is information; an unsourced number is not.

### Source hierarchy

| Preferred | Statistical agencies (USGS, FAO, Eurostat), regulators and central banks, trade bodies publishing their own data (WPIC, ICCO, IOC, Silver Institute, ICSG, SWA, Comité Champagne, CITES), company filings and audited accounts, peer-reviewed research |
| Used with attribution | Trade press reporting primary data (halfwheel, Cigar Aficionado, Decanter, Liv-ex, Hagerty, Artnet), auction-house results |
| Marked and never headlined | Market-research vendor sizing, merchant and retailer price guides, advocacy and industry-funded bodies where the funder has an interest in the conclusion |

Where a body funds the research it publishes — the World Platinum Investment Council is the clearest case — the page says so and names the independent cross-check.

### Prices

**No live prices or index levels.** ΣΟΦΙΑ pages are static and would be wrong within days. Historical price points appear with their dates and remain as history. Forecasts are recorded as a named house's view at the date made and are never quietly updated — a forecast that was wrong is more informative than one silently corrected. Where an exchange benchmark exists it is named under Indicators and left to the reader to consult.

### Discrepancies

Where credible sources conflict, the page shows both figures, states which is used and why, and tags the confidence. Silent reconciliation is not permitted. This is not a disclaimer habit; in several markets the disagreement is the finding. The World Platinum Investment Council's own 2025 platinum deficit moved from 966 koz to 692 koz to 1,082 koz across three quarterly reports — a reader who sees only the final number learns less than one who sees the path.

### Inference

Cross-market parallels, structural readings and compliance observations are ΣΟΦΙΑ's own analysis. They are tagged **Hyp** wherever they appear and are never presented as sourced fact.

---

## 4. Tags

Two tags attach to claims. They answer different questions and both may apply.

### Confidence — how far the claim can be trusted

| Tag | Basis |
|---|---|
| **High** | Primary or institutional source, checked against at least one independent statement |
| **Med** | Secondary report of primary data, or a single institutional source not independently confirmed |
| **Low** | Vendor, retailer, advocacy or single trade source; shown for orientation, not for reliance |
| **Hyp** | ΣΟΦΙΑ's own inference or cross-market parallel; not a fact about the world |

### Data label — how the number was made

| Label | Meaning |
|---|---|
| **Reported** | Stated by the cited source |
| **Derived** | Calculated by ΣΟΦΙΑ from reported figures; the calculation is shown |
| **Estimate** | An approximation, by the source or by ΣΟΦΙΑ, with its basis stated |
| **Forecast** | Forward-looking, recorded with its date and author |

---

## 5. The Market Snapshot

A compact block at the head of each sector page. Eight fields, four of them rated.

| Field | Content |
|---|---|
| Price regime | One dated qualitative line; never a number |
| Primary origins | Three to five places |
| Principal markets | Three to five places |
| Supply concentration | Low / Medium / High — Scale A |
| Liquidity | Low / Medium / High — Scale B |
| Scarcity | Low / Medium / High — Scale C |
| Provenance risk | Low / Medium / High — Scale D |
| Data as of | Compile date |

Each rating carries a confidence tag and cites the section of the page that evidences it. A rating is a claim, held to the same standard as any other claim.

### Scale A — Supply concentration

Where the power to set price sits, not where the material comes out of the ground.

| Band | Criterion |
|---|---|
| **High** | Top three suppliers or controllers ≥ 75%, or a single supplier or controller ≥ 50% |
| **Medium** | Top three between 50% and 74% |
| **Low** | Top three below 50% |

The bands are exhaustive: every market falls in exactly one. Rate the most concentrated stage that binds price, and name it. Rare earths are rated on separation, not mining — China's mine share is about 69%, its separation share above 85% and its heavy-rare-earth share 98–99%. Cocoa is rated on two marketing boards, not on millions of farms. Port is rated on the benefício and two family groups, not on 19,000 growers. Where an institutional or processing bottleneck makes concentration materially greater than primary production suggests, the bottleneck is rated and a one-line note explains the choice.

### Scale B — Liquidity

Whether a standard unit can be turned into money at a price the seller could have known in advance.

| Band | Criterion |
|---|---|
| **High** | An exchange or daily reference price exists and standard units clear daily |
| **Medium** | No exchange, but a regular auction, index or dealer market gives price discovery within weeks |
| **Low** | Private, irregular or ceremonial sales; no reference price |

Liquidity is rated for the market, not the moment. A whisky cask and a bottle of the same whisky rate differently, and the page says which is rated.

### Scale C — Scarcity

Whether supply can respond to price, and how quickly.

| Band | Criterion |
|---|---|
| **High** | Supply is fixed or falling and cannot be expanded by investment within five years |
| **Medium** | Supply responds with a lag of three to five years |
| **Low** | Supply responds within a year or two, or a substitute exists at scale |

Rated for the tier the page centres on. Many of these markets have a scarce apex and an abundant base — wild white truffles against farmed black, Ōma bluefin against ranched, a pure white gyrfalcon against a hybrid, Uji tencha against Kagoshima. The page rates the apex and says so. Substitution counts: lab-grown diamonds, synthetic vanillin, copper metallisation in solar cells and 2,4-dithiapentane truffle oil all pull a rating toward Low regardless of what the natural supply does.

### Scale D — Provenance risk

The chance that origin, species, grade or lineage is misstated, weighed against the strength of the control that would catch it.

| Band | Criterion |
|---|---|
| **High** | Documented mislabelling above 20% in market studies, or no independent verification exists |
| **Medium** | Certification exists but is voluntary, producer-run, or unable to detect substitution |
| **Low** | A mandatory, independent, forensic control exists at the point of trade |

The distinction that matters is between certifying paperwork and certifying contents. A CITES caviar label, a Kimberley Process certificate and a phytosanitary certificate all attest that a document was issued; none attests that the tin, the parcel or the box holds what the document describes. A 2023 genetic study of 149 Lower-Danube caviar samples found 21% illegally wild-caught and 32% deceptive to the consumer — every one of them labelled. Laboratory verification at the point of import is a Low control; a label is not.

### No composite score

ΣΟΦΙΑ does not publish a single scarcity number. A composite would require weighting four scales against each other, and no defensible weighting exists across markets as different as copper and Arabian horses. The four ratings are published separately and the reader weighs them. This position will be reconsidered only after the scales have been through a full refresh cycle across every sector, and any composite would be published with its formula.

---

## 6. Refresh, correction and versioning

**Data as of.** Every page carries the date its figures were compiled. Nothing on a page is presented as current beyond that date.

**Refresh.** A refresh re-verifies figures against current primary sources, updates what has changed with new dates, retains the history, and logs corrections in the relevant source entry. Design and structure are not altered in a refresh.

**Ratings.** Snapshot ratings are reviewed at refresh, not between refreshes. A rating that changes carries a note of what changed and why.

**Corrections.** Errors are corrected on the page and noted in the source entry, not removed. Where a page has previously repeated a common misattribution, the correction is stated explicitly so the reader can recognise it elsewhere.

**Versioning.** This methodology is versioned. Pages cite the version under which they were rated.

---

## Appendix — draft sector ratings, pending approval

Proposed from each page's own evidence. **Not published and not in force.** Any row not approved is left blank on the page rather than guessed.

| Sector | Supply conc. | Liquidity | Scarcity (tier rated) | Provenance risk | Confidence |
|---|---|---|---|---|---|
| Natural diamonds | Medium (mining); High (rough distribution) | Medium | Medium; large stones High | Medium | Med |
| Lab-grown diamonds | Medium | Medium | Low | Medium | Med |
| Coloured gemstones | Medium–High by stone | Low | High (top origins) | High | Med |
| Pearls | Medium | Low | Medium; natural High | Medium | Low |
| Gold | Low (mine); Medium (refining) | High | Low | Medium (doré origin) | High |
| Silver | Medium | High | Medium | Low | High |
| Platinum group metals | High | High | Medium | Low | High |
| Copper | Medium (mine); High (refining) | High | Medium | Low | High |
| Rare earths | High (separation) | Medium | Medium | Medium | High |
| Oil & gas | Medium | High | Low | Low | Med |
| Fine wine | Low | Medium | Medium; top Burgundy High | Medium | High |
| Port | High | Medium | Medium; Vintage High | Low | High |
| Scotch whisky | High | Medium (bottles); Low (casks) | Medium; closed distilleries High | High (casks) | High |
| Cigars | High | Low | Medium | High | High |
| Watches | High | Medium | Low | Medium | High |
| Art | Low | Medium (auction); Low (private) | High | Medium | High |
| Classic cars | Low | Medium | High (top); Low (base) | Medium | Med |
| Saffron | High | Low | Medium | High | Med |
| Oud | Medium | Low | High (wild); Low (plantation) | High | High |
| Vanilla | High | Low | Low | Medium | High |
| Frankincense | Medium | Low | Medium; *B. papyrifera* High | High | High |
| Coffee | Medium | High | Low; Geisha High | Medium | High |
| Tea | High | Medium | Low; Uji tencha High | Medium | High |
| Cocoa | High (boards) | High | Low | Medium | High |
| Olive oil | High | Medium | Low | High | High |
| Mānuka honey | High | Low | Medium | Medium; High outside NZ | High |
| Dates | Medium | Low | Low; Ajwa Medium | Medium | Med |
| Caviar | Medium–High | Low | Low (farmed); High (wild) | High | High |
| Truffles | Medium | Low (white); Medium (black) | High (white); Low (black) | High | Med |
| Bluefin tuna | Medium | Medium | High (wild Ōma) | Medium | High |
| Wagyu | High | Medium | Low | Medium | High |
| Falcons | High | Low | High (pure white gyr) | Medium | Med |
| Arabian horses | Low | Low | High (champions); Low (base) | Low | Med |

**To approve:** the four scales (§5), then each row above. Once approved, the Snapshot block is inserted across all sector pages in a single pass with a validation check.
