# Build brief — ΣΟΦΙΑ (saphia.io)

Paste the block below into Claude Design as a single prompt. Attach `index.html`, `methodology.html` and two or three dashboards (suggest `gold_dashboard.html`, `fine_wine_dashboard.html`, `oud_dashboard.html`) so the tone and the existing pages are visible. Everything after the line is the prompt.

---

Design and build the website for **ΣΟΦΙΑ** (domain: saphia.io), a specialist market-intelligence publisher. Deliver production-ready static HTML/CSS with minimal vanilla JS — no framework, no build step, no external scripts beyond Google Fonts. Every page must be self-contained and deployable by dropping files into static hosting.

## What ΣΟΦΙΑ is

ΣΟΦΙΑ publishes cited, confidence-rated intelligence on 33 scarce-asset markets — diamonds, gold, copper, rare earths, fine wine, Port, Scotch whisky, cigars, watches, art, classic cars, saffron, oud, vanilla, frankincense, coffee, tea, cocoa, olive oil, mānuka honey, dates, caviar, truffles, bluefin tuna, wagyu, falcons, Arabian horses and others. The proposition is not coverage breadth; it is that unrelated markets are analysed through one lens: **supply → demand → concentration → liquidity → scarcity → provenance → price formation**.

Tagline: **Scarce assets. One perspective.**
Descriptor, always paired with the wordmark: **SCARCE ASSETS INTELLIGENCE**.
Positioning line: *Intelligence on the world's scarce assets.*

It publishes market intelligence and data. It does not publish investment advice. Nothing on the site should read as a recommendation, and no page carries live prices or index levels.

## Identity

- Wordmark is the Greek **ΣΟΦΙΑ**, set in a serif with real Greek glyphs (EB Garamond works; Cormorant Garamond and Spectral also do). Generous letter-spacing, roughly .14em. The descriptor sits beneath it in mono at about 10px, letter-spaced .32em. saphia.io appears only in page titles and as the domain — never as the visual mark.
- Palette: warm off-white paper (#f4efe6), near-black ink (#141412), muted grey (#6f6a62), hairline rule (#dcd4c6), single bronze accent (#a8825a). One accent only.
- Typography: a serif for display and headlines, a neutral sans for body at 300–400 weight, a monospace for labels, numbers, dates and eyebrows. Three families, no more.
- The background is grainy paper: an inline SVG fractal-noise filter as a data URI, multiplied over the base colour at low opacity, fixed-position so it does not scroll, with a faint warm vignette at the edges. Implementation note that matters: put the base colour on `html` and the noise layer on `body::before` at z-index −1, or the body background paints over the grain.
- No photography, no illustration, no stock imagery, no gradients beyond the paper wash, no cards with drop shadows. Rules, type and whitespace carry the design.

## Reference material

The attached `index.html` and `methodology.html` are the current versions, already built to this system — treat them as the floor, not the ceiling. The attached dashboards show the house style for a sector page: Roman-numeral sections, a contents block, floating previous/next/top controls, confidence tags (High/Med/Low/Hyp), data labels (Reported/Derived/Estimate/Forecast), and a numbered source list. Each dashboard has its own palette and layout motif drawn from its subject; the site chrome must not fight them.

## Pages to build

**1. Home.** Wordmark and descriptor top-left; nav right (Markets, Latest, The Brief, Methodology, Sign in). A tall, quiet hero: the positioning line as the only large type, a short bronze rule, the six axes in mono (Markets · Prices · Supply · Demand · Trade · Provenance), one outlined call to action. Then substantial whitespace. Then "Explore the markets" — seven families as plain text link lists, no cards, no icons, with "Scarce assets. One perspective." set small to the right. Then "Latest intelligence": three rows only, each sector name, one-line finding, date, arrow. Then "The Saphia Brief": *Six observations. Five minutes. Once a week.* and an email field. Then one line — *One analytical language across fundamentally different markets* — the seven-step sequence in mono, and a quiet link to the methodology. Footer: wordmark, tagline, "Dubai · Global".

The seven families, in this order:
1. Gems & Jewellery — Natural Diamonds, Lab-Grown Diamonds, Coloured Gemstones, Pearls
2. Metals, Energy & Strategic Materials — Gold, Silver, Platinum Group Metals, Copper, Rare Earths, Oil & Gas
3. Cellar & Collectibles — Fine Wine, Port, Scotch Whisky, Cigars, Watches, Art, Classic Cars
4. Aromatics — Saffron, Oud, Vanilla, Frankincense
5. Crops — Coffee, Tea, Cocoa, Olive Oil, Mānuka Honey, Dates
6. Rare Foods — Caviar, Truffles, Bluefin Tuna, Wagyu
7. Heritage & Bloodstock — Falcons, Arabian Horses

Never display a sector count as a headline figure; the number changes and is not the proposition.

**2. Markets index.** A fuller directory than the homepage list: the same seven families, each sector with a one-line description and its data-as-of date. Filterable by family with plain JS, no library. Must work with JS disabled.

**3. Sector page template.** A wrapper that hosts an existing dashboard's content: breadcrumb (Markets / Gold), sector title, a one-line positioning phrase, then a **Market Snapshot** block, then the dashboard body, then sources. The Snapshot is eight fields — Price regime (a dated qualitative line, never a number), Primary origins, Principal markets, Supply concentration, Liquidity, Scarcity, Provenance risk, Data as of — with the four middle fields rated Low/Medium/High, each carrying a confidence tag and linking to the methodology. Design this block carefully: it is the most repeated element on the site and the one piece of proprietary apparatus.

**4. Methodology.** Already drafted and attached; rebuild it in the final system. It carries the analytical sequence, the confidence and label definitions, the price and discrepancy rules, and the four rating scales as tables.

**5. The Brief.** Archive page listing past issues, each with date, three-line summary and a link; signup at the top.

**6. About.** Short. What ΣΟΦΙΑ analyses, how, and the not-investment-advice position. No team photographs.

## Behaviour and constraints

- Responsive with no horizontal overflow at 390px. Tables scroll inside their own container; grid children get `min-width:0`. Test at 390 and 1280.
- Accessible: semantic landmarks, visible focus rings, `aria-label` on icon controls, contrast that passes at body size, `prefers-reduced-motion` respected.
- Fast and quiet: no animation beyond a hover state and smooth scrolling; no analytics; no cookie banner because there are no cookies.
- The email form is a placeholder until a mailing provider is connected — say so in small print rather than faking a submission.
- Per-page inline `<style>` is acceptable if it keeps files self-contained; a single shared stylesheet is also fine. State which you chose.
- UK English throughout.

## What to deliver

Working HTML for the six page types, the shared CSS system (documented tokens: colour, type scale, spacing, the grain treatment), the Snapshot component with markup ready to populate, and a short note on how a new sector page is added. Show the homepage and the Snapshot component first for approval before building the rest.

## What to avoid

Quiet-luxury clichés: full-bleed hero photography, serif-over-image, "curated" and "bespoke" as copy, testimonial carousels, logo walls, animated counters, gradient buttons, glassmorphism. Also avoid anything that implies advice — no "recommended", no "buy/sell", no portfolio language. The site should read like a research institution's, not a broker's.
